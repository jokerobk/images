# big_screen
数据大屏可视化

# 功能

便利性工具, 结构简单, 直接传数据就可以实现数据大屏

# 安装

```
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple flask
```

# 运行

```
cd big_screen;
python app.py;
```

* 大数据可视化展板通用模板 http://127.0.0.1:5000/        


# 参考

> https://gitee.com/lvyeyou/DaShuJuZhiDaPingZhanShi

# 数据来源
> 国家统计局 http://www.stats.gov.cn/tjsj/zxfb/202112/t20211206_1825058.html
