from flask import Flask, render_template
from data import SourceData

app = Flask(__name__)   # 初始化app


@app.route('/')         # 定义路由
def index():
    data = SourceData()
    return render_template('index.html', form=data, title=data.title)   # 定义路由执行结果


if __name__ == "__main__":
    app.run(host='127.0.0.1', debug=False)  # 运行app
