class SourceDataDemo:

    def __init__(self):
        self.title = '粮食产量'
        self.counter = {'name': '2021年总播种面积(千公顷)', 'value': 117631.5}
        self.counter2 = {'name': '2021年粮食总产量(万吨)', 'value': 68285.1}
        self.echart1_data = {
            'title': '播种面积（千公顷）',
            'data': [
                {"name": "稻谷", "value": 29921.2},
                {"name": "小麦", "value": 23568.4},
                {"name": "玉米", "value": 43324.1},
                {"name": "豆类", "value": 10120.7},
                {"name": "薯类", "value": 7333.4},

            ]
        }
        self.echart2_data = {
            'title': '总产量（万吨）',
            'data': [
                {"name": "稻谷", "value": 21284.3},
                {"name": "小麦", "value": 13694.6},
                {"name": "玉米", "value": 27255.2},
                {"name": "豆类", "value": 1965.5},
                {"name": "薯类", "value": 3043.5},

            ]
        }
        self.echarts3_1_data = {
            'title': '播种面积（千公顷）',
            'data': [
                {"name": "夏粮", "value": 26437.9},
                {"name": "早稻", "value": 4734.1},
                {"name": "秋粮", "value": 86459.5},

            ]
        }
        self.echarts3_2_data = {
            'title': '总产量（万吨）',
            'data': [
                {"name": "夏粮", "value": 14595.7},
                {"name": "早稻", "value": 2801.6},
                {"name": "秋粮", "value": 50887.8},

            ]
        }
        self.echarts3_3_data = {
            'title': '单位面积产量（公斤/公顷）',
            'data': [
                {"name": "夏粮", "value": 5520.7},
                {"name": "早稻", "value": 5918.0},
                {"name": "秋粮", "value": 5885.7},

            ]
        }
        self.echart4_data = {
            'title': '油料和棉花产量',
            'data': [
                {"name": "棉花", "value": [571.42, 753.28, 759.71, 723.23, 623.58, 577.04, 651.89, 660.80, 628.16, 629.94, 590.74, 534.28, 565.25, 610.28, 588.90, 591.05, 573.00]},
                {"name": "油料", "value": [3077.14, 2640.31, 2786.99, 3036.76, 3139.42, 3156.77, 3212.51, 3285.62, 3348.00, 3371.92, 3390.47, 3400.05, 3475.24, 3433.39, 3492.98, 3586.40, 3613.00]},
            ],
            'xAxis': ['2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2019', '2020',
                      '2021'],
        }
        self.echart5_data = {
            'title': '省份TOP',
            'data': [
                {"name": "黑龙江", "value": 14},
                {"name": "河南", "value": 10},
                {"name": "山东", "value": 8.3},
                {"name": "安徽", "value": 7.3},
                {"name": "内蒙古", "value": 6.8},
                {"name": "河北", "value": 6.4},
                {"name": "四川", "value": 6.3},
                {"name": "吉林", "value": 5.7},
            ]
        }
        self.echart6_data = {
            'title': '一线城市情况',
            'data': [
                {"name": "浙江", "value": 45, "value2": 55, "color": "01", "radius": ['59%', '70%']},
                {"name": "上海", "value": 15, "value2": 85, "color": "02", "radius": ['49%', '60%']},
                {"name": "广东", "value": 90, "value2": 10, "color": "03", "radius": ['39%', '50%']},
                {"name": "北京", "value": 5, "value2": 95, "color": "04", "radius": ['29%', '40%']},
                {"name": "天津", "value": 25, "value2": 75, "color": "05", "radius": ['20%', '30%']},
            ]
        }
        self.map_1_data = {
            'symbolSize': 100,
            'data': [
                {'name': '海门', 'value': 239},
                {'name': '鄂尔多斯', 'value': 231},
                {'name': '招远', 'value': 203},
            ]
        }

    @property
    def echart1(self):
        data = self.echart1_data
        echart = {
            'title': data.get('title'),
            'xAxis': [i.get("name") for i in data.get('data')],
            'series': [i.get("value") for i in data.get('data')]
        }
        return echart

    @property
    def echart2(self):
        data = self.echart2_data
        echart = {
            'title': data.get('title'),
            'xAxis': [i.get("name") for i in data.get('data')],
            'series': [i.get("value") for i in data.get('data')]
        }
        return echart

    @property
    def echarts3_1(self):
        data = self.echarts3_1_data
        echart = {
            'title': data.get('title'),
            'xAxis': [i.get("name") for i in data.get('data')],
            'data': data.get('data'),
        }
        return echart

    @property
    def echarts3_2(self):
        data = self.echarts3_2_data
        echart = {
            'title': data.get('title'),
            'xAxis': [i.get("name") for i in data.get('data')],
            'data': data.get('data'),
        }
        return echart

    @property
    def echarts3_3(self):
        data = self.echarts3_3_data
        echart = {
            'title': data.get('title'),
            'xAxis': [i.get("name") for i in data.get('data')],
            'data': data.get('data'),
        }
        return echart

    @property
    def echart4(self):
        data = self.echart4_data
        echart = {
            'title': data.get('title'),
            'names': [i.get("name") for i in data.get('data')],
            'xAxis': data.get('xAxis'),
            'data': data.get('data'),
        }
        return echart

    @property
    def echart5(self):
        data = self.echart5_data
        echart = {
            'title': data.get('title'),
            'xAxis': [i.get("name") for i in data.get('data')],
            'series': [i.get("value") for i in data.get('data')],
            'data': data.get('data'),
        }
        return echart

    @property
    def echart6(self):
        data = self.echart6_data
        echart = {
            'title': data.get('title'),
            'xAxis': [i.get("name") for i in data.get('data')],
            'data': data.get('data'),
        }
        return echart

    @property
    def map_1(self):
        data = self.map_1_data
        echart = {
            'symbolSize': data.get('symbolSize'),
            'data': data.get('data'),
        }
        return echart


class SourceData(SourceDataDemo):

    def __init__(self):
        """
        按照 SourceDataDemo 的格式覆盖数据即可
        """
        super().__init__()
        self.title = '粮食产量'
